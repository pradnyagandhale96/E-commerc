package com.ecommerce.sportscenter.entity.OrderAggregate;

public enum OrderStatus {
    Pending,
    PaymentReceived,
    PaymentFailed
}
